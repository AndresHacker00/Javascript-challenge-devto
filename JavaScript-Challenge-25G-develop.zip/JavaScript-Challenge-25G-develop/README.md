# JavaScript-Challenge-25G
Est repositorio aloja el projecto del equipo conformado por Damian, Paola, Andres Garcia, Andres de Anda, Saidel
